function goToSignInPage(){
    location.href='signin'
}

function goToRegisterPage(){
    location.href='register'
}

function addedToPlaylist(){
    console.log("Clicked!!!")
}