from django.apps import AppConfig


class MusicialConfig(AppConfig):
    name = 'musicial'
